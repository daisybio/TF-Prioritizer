g++ TRAPmulti.cpp -O3 -fopenmp -o TRAPmulti
Rscript installRpackages.R
